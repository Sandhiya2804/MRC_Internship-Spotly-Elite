package com.example.Project_team_5.Repository;

import com.example.Project_team_5.Model.Admin_T5;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Admin_T5Repository extends JpaRepository<Admin_T5, Long> {
}
