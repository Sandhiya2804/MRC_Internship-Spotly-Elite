package com.example.Project_team_5.Repository;

import com.example.Project_team_5.Model.Request_T5;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface Request_T5Repository extends JpaRepository<Request_T5, Integer> {
}

