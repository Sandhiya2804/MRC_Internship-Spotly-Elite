package com.example.Project_team_5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestProjectTeam5Application {
	public static void main(String[] args){
		SpringApplication.run(ProjectTeam5Application.class,args);
	}
}
