import React from 'react';

function Register() {
  return (
    <div>
      <h2>Register Page</h2>
      
    </div>
  );
}

export default Register;